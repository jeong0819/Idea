package com.example.realp;

public class BB_ListData2 {
    private int bNumber;
    private String imageUrl;

    public BB_ListData2(int bNumber, String imageUrl) {
        this.bNumber = bNumber;
        this.imageUrl = imageUrl;
    }

    public int getbNumber() {
        return bNumber;
    }

    public void setbNumber(int bNumber) {
        this.bNumber = bNumber;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
