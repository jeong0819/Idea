package com.example.realp;

class ChaseData {
    private String pWorker;

    public ChaseData(String pWorker) {
        this.pWorker = pWorker;
    }

    public String getpWorker() {
        return pWorker;
    }

    public void setpWorker(String pWorker) {
        this.pWorker = pWorker;
    }
}
