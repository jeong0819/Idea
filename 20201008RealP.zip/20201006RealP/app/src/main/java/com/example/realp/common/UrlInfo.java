package com.example.realp.common;

public class UrlInfo {
    public static String LOGIN_URL = "http://teamwhi.dothome.co.kr/login.php";
    public static String SIGN_UP_URL = "http://teamwhi.dothome.co.kr/signup.php";
    public static String NICK_CHECK_URL = "http://teamwhi.dothome.co.kr/nick_check.php";
    public static String ID_CHECK_URL = "http://teamwhi.dothome.co.kr/id_check.php";

}